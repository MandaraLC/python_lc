
#要解析的文件
file = open("./newlist/listAll_cairuliu20190509_70_110_7.txt")

#要写入的文件
f = open('./newlist/listAll_cairuliu20190509_70_110_8.txt', 'a')

while 1:
    line = file.readline()
    if "32, 33" not in line:
        f.write(line)

    if not line:
        break
    pass
file.close()