#coding=utf-8
#! /usr/bin/python
import random
import linecache
def hello():
    file = 'listAll_cairuliu20190509.txt'
    count = len(open(file, 'r').readlines())#获取行数
    hellonum=random.randrange(1,count, 1)#生成随机行数
    return linecache.getline(file, hellonum)#随机读取某行
if __name__ == "__main__":
    with open('result.txt', 'a+') as f:
        for i in range(1):
            #print(hello())
            f.write(hello())
            #print(hello())