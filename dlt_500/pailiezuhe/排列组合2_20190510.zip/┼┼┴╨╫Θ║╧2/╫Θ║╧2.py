import copy
import random
import operator

def multiplyList(myList):
    result = 0
    for x in myList:
        result = result + x
    return result

def combine(lst, l):
    result = []
    tmp = [0]*l
    length = len(lst)
    def next_num(li=0, ni=0):
        if ni == l:
            f = open('listAll_cairuliu20190510_70_110.txt', 'a')
            if multiplyList(copy.copy(tmp)) >= 70 and multiplyList(copy.copy(tmp)) <= 110:
            #if multiplyList(copy.copy(tmp)) == 17 or multiplyList(copy.copy(tmp)) == 163:
                f.write("".join(str(copy.copy(tmp)))+"==>"+str(multiplyList(copy.copy(tmp))))
                f.write('\n')
            result.append(copy.copy(tmp))
            return
        for lj in range(li,length):
            tmp[ni] = lst[lj]
            next_num(lj+1, ni+1)
    next_num()
    return result

#remove 10,15,20,23,24
ll = combine([3,4,5,6,9,11,12,14,17,18,19,21,22,27,28,29,30,31,32,33], 5)
#ll = combine([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35], 5)

# print(len(ll))
# print(ll)